const express = require('express');
const router = express.Router();
const axios = require('axios');
const authMiddleware = require('../middleware/authMiddleware');
const GeneratedContent = require('../models/GeneratedContent');

// Save AI-generated content
router.post('/save', authMiddleware, async (req, res) => {
    const { topic, type, goal, tone, mood, content } = req.body;
    try {
        const newContent = await GeneratedContent.create({
            user_id: req.user.id,
            topic, type, goal, tone, mood, content
        });
        res.json({ success: true, content_id: newContent._id });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'DB error' });
    }
});

// Fetch user content (dashboard/history)
router.get('/dashboard', authMiddleware, async (req, res) => {
    try {
        const contents = await GeneratedContent.find({ user_id: req.user.id }).sort({ created_at: -1 });
        res.json(contents);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'DB error' });
    }
});

// Generate content via n8n AI webhook
router.post('/generate', authMiddleware, async (req, res) => {
    try {
        const { topic, type, goal, tone, mood } = req.body;
        const response = await axios.post(process.env.N8N_WEBHOOK_URL, {
            user_id: req.user.id,
            topic, type, goal, tone, mood
        });

        const generatedContent = response.data.content; // n8n should return { content: "..." }

        // Save generated content
        await GeneratedContent.create({
            user_id: req.user.id,
            topic, type, goal, tone, mood,
            content: generatedContent
        });

        res.json({ content: generatedContent });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'AI generation failed' });
    }
});

// Update content
router.put('/:id', authMiddleware, async (req, res) => {
  const { id } = req.params;
  const { topic, type, goal, tone, mood, content } = req.body;

  try {
    const updatedContent = await GeneratedContent.findOneAndUpdate(
      { _id: id, user_id: req.user.id },
      { topic, type, goal, tone, mood, content },
      { new: true }
    );

    if (!updatedContent) {
      return res.status(404).json({ error: 'Content not found' });
    }

    res.json({ success: true, updatedContent });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete content
router.delete('/:id', authMiddleware, async (req, res) => {
  const { id } = req.params;

  try {
    const deletedContent = await GeneratedContent.findOneAndDelete({ _id: id, user_id: req.user.id });

    if (!deletedContent) {
      return res.status(404).json({ error: 'Content not found' });
    }

    res.json({ success: true, message: 'Content deleted successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});


module.exports = router;
